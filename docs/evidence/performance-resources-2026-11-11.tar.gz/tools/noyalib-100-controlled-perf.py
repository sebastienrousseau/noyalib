from pathlib import Path
import subprocess,json,os,time,hashlib,re,signal,datetime,shutil
root=Path('/Users/seb/Code/Public/Rust/noyalib');base=Path('/private/tmp/noyalib-ecosystem-assessment-2026-11-10');out=Path('/private/tmp/noyalib-100-controlled-performance');out.mkdir(exist_ok=True)
builds=json.loads(Path('/private/tmp/noyalib-100-perf-build/summary.json').read_text());assert len(builds)==6 and all(row['exit_code']==0 for row in builds)
def command(args,cwd=root):return subprocess.check_output(args,cwd=cwd,text=True).strip()
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
meta={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'protocol':{'warm_up_seconds':2,'measurement_seconds':3,'samples':30,'repetitions':3,'own_fuzz_scheduler_paused':True,'dedicated_machine':False,'scope':'Sequential optimized in-process Criterion suites on local macOS; own compiler and fuzz workers absent, external host work not excluded. Not end-to-end protocol latency or a dedicated CI timing threshold.'},'host':{key:command(args) for key,args in {'os':['sw_vers'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'logical_cpus':['sysctl','-n','hw.logicalcpu'],'rustc':['rustc','-Vv'],'cargo':['cargo','-V'],'node':['node','--version']}.items()},'sources':{}}
for name in ['noyalib','noya-cli','noyalib-lsp','noyalib-mcp','noyalib-wasm','noyalib-serde-yaml']:
 repo=root if name=='noyalib' else base/name
 meta['sources'][name]={'commit':command(['git','rev-parse','HEAD'],repo),'status':command(['git','status','--short'],repo),'lock_sha256':digest(repo/'Cargo.lock')}
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');rows=[]
try:
 for repetition in range(1,4):
  for row in builds:
   name=row['repo'];bench=row['bench'];repo=root if name=='noyalib' else base/name;label=f'{name}-{bench}-r{repetition}';dest=out/label;dest.mkdir(exist_ok=True)
   log=Path('/private/tmp/noyalib-100-perf-build')/(name+'-'+bench+'.log');found=re.findall(r'Executable .*?\(([^)]+)\)',log.read_text())[-1];binary=Path(found);binary=binary if binary.is_absolute() else root/binary;assert binary.is_file()
   args=[str(binary),'--bench','--warm-up-time','2','--measurement-time','3','--sample-size','30','--noplot'];load=os.getloadavg();start=time.monotonic()
   with (dest/'console.log').open('w') as stream:r=subprocess.run(args,cwd=repo,stdout=stream,stderr=subprocess.STDOUT,env={**os.environ,'CRITERION_HOME':str(dest/'criterion')})
   receipt={'repo':name,'bench':bench,'repetition':repetition,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'load_before':load,'load_after':os.getloadavg(),'binary_sha256':digest(binary),'command':args}
   (dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');rows.append(receipt);(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,flush=True)
   if r.returncode:raise RuntimeError('Benchmark failed: '+label)
  wasm=base/'noyalib-wasm';label=f'noyalib-wasm-r{repetition}';dest=out/label;dest.mkdir(exist_ok=True);start=time.monotonic()
  with (dest/'console.log').open('w') as stream:r=subprocess.run(['node','benches/bench.js'],cwd=wasm,stdout=stream,stderr=subprocess.STDOUT,env={**os.environ,'NOYALIB_WASM_BENCH_JSON':str(dest/'results.json')})
  receipt={'repo':'noyalib-wasm','bench':'real-js-boundary','repetition':repetition,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'load_after':os.getloadavg()};rows.append(receipt);(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,flush=True)
  if r.returncode:raise RuntimeError('WASM benchmark failed')
 resource_log=out/'resource-receipts.log'
 with resource_log.open('w') as stream:r=subprocess.run(['python3','/private/tmp/noyalib-100-collect-resources.py'],stdout=stream,stderr=subprocess.STDOUT)
 print('Signed-source resource receipts',r.returncode,flush=True)
 if r.returncode:raise RuntimeError('Resource receipts failed')
finally:
 control=Path('/private/tmp/noyalib-100-perf-quiet-control.json');state=json.loads(control.read_text())
 if state['scheduler_paused']:
  os.kill(52447,signal.SIGCONT);state['scheduler_paused']=False;state['resumed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();control.write_text(json.dumps(state,indent=2)+'\n');print('Historical scheduler resumed',flush=True)
