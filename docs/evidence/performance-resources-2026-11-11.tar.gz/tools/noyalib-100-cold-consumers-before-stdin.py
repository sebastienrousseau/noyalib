"""Measure complete cold-process consumer cycles using the existing parity clients."""
from pathlib import Path
import importlib.util,subprocess,sys,json,hashlib,time,os,statistics,datetime
try:
 import resource
except ImportError:
 resource=None
root=Path('/Users/seb/Code/Public/Rust/noyalib');out=Path('/private/tmp/noyalib-100-controlled-performance/cold-consumers');out.mkdir(exist_ok=True)
name=sys.argv[1]
repo={'cli':'noya-cli','lsp':'noyalib-lsp','mcp':'noyalib-mcp'}[name];exe={'cli':'noyafmt','lsp':'noyalib-lsp','mcp':'noyalib-mcp'}[name]
binary=root/'target/ecosystem-v0.0.61'/('performance-'+repo)/'release'/exe
assert binary.is_file(),binary
script=root/'scripts/check-ecosystem-parity.py';spec=importlib.util.spec_from_file_location('parity',script);parity=importlib.util.module_from_spec(spec);spec.loader.exec_module(parity)
fixture='port:   8080\n';rows=[]
for repetition in range(1,4):
 samples=[]
 for _ in range(40):
  start=time.perf_counter_ns()
  if name=='cli':
   r=parity.invoke([str(binary)],fixture);assert r.returncode==0,r.stderr;assert r.stdout=='port: 8080\n',r.stdout
  elif name=='lsp':
   text,errors=parity.lsp(str(binary),fixture);assert not errors,errors;assert text=='port: 8080\n',text
  else:
   value,error=parity.mcp(str(binary),fixture,root);assert not error and value=={'port':8080},(value,error)
  samples.append((time.perf_counter_ns()-start)/1e6)
 ordered=sorted(samples);row={'repetition':repetition,'samples_ms':samples,'p50_ms':statistics.median(samples),'p95_ms':ordered[37],'load_average':os.getloadavg()};rows.append(row)
 print(name,repetition,row['p50_ms'],row['p95_ms'],flush=True)
peak=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss if resource else None
if peak is not None and sys.platform!='darwin':peak*=1024
j={'measured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'product':repo,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'parity_client_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'measurement_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256(fixture.encode()).hexdigest(),'binary_profile':'optimized default-feature release from the recorded benchmark build','scope':'Complete cold child-process cycle including spawn, protocol initialization/discovery where used, one checked operation and shutdown. Not warmed request latency. Shared local host; no dedicated-hardware timing gate.','max_child_rss_bytes':peak,'rss_scope':'Kernel maximum child-process RSS across this product-only collection; macOS bytes, Linux KiB converted to bytes. No claim about unmeasured transient per-operation peaks.','repetitions':rows}
(out/(repo+'.json')).write_text(json.dumps(j,indent=2)+'\n')
