from pathlib import Path
import subprocess,json,hashlib,os
root=Path('/private/tmp/noyalib-ecosystem-assessment-2026-11-10/noyalib-wasm');out=Path('/private/tmp/noyalib-100-resource-receipts-signed-2ed44f3');out.mkdir(exist_ok=True)
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert source=='2ed44f3aee8d76128b903b57d1371332e511a12f'
assert not subprocess.check_output(['git','diff','--','src','scripts','Cargo.toml','Cargo.lock'],cwd=root,text=True)
rows=[]
for number,mode in enumerate(['normal','normal','normal','leak','js-leak','lost-metrics'],1):
 args=['node','--expose-gc','scripts/check-runtime-resources.mjs','pkg-node',mode];log=out/(str(number)+'-node-'+mode+'.json');err=log.with_suffix('.stderr')
 with log.open('w') as stream,err.open('w') as errors:r=subprocess.run(args,cwd=root,stdout=stream,stderr=errors)
 j=json.loads(log.read_text());expected=0 if mode=='normal' else 1;assert r.returncode==expected,(mode,r.returncode)
 rows.append({'source_commit':source,'core_production_source':'a57b7198669e41fe3034db4e44f2e274baf96388','runtime':'Node','mode':mode,'command':args,'exit_code':r.returncode,'report':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()});print('Node',mode,r.returncode,j['growth_bytes'],j['js_heap_growth_bytes'],flush=True)
for number,mode in enumerate(['normal','normal','normal','leak','js-leak'],1):
 args=['node','scripts/check-installed-consumer.mjs','pkg','/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','--resources']
 if mode=='leak':args+=['--inject-leak']
 if mode=='js-leak':args+=['--inject-js-leak']
 log=out/(str(number)+'-browser-'+mode+'.json');err=log.with_suffix('.stderr')
 with log.open('w') as stream,err.open('w') as errors:r=subprocess.run(args,cwd=root,stdout=stream,stderr=errors)
 j=json.loads(log.read_text());expected=0 if mode=='normal' else 1;assert r.returncode==expected,(mode,r.returncode)
 m=j['bundle']['runtime_resources'] if mode=='normal' else j['runtime_resources']
 rows.append({'source_commit':source,'core_production_source':'a57b7198669e41fe3034db4e44f2e274baf96388','runtime':'Chromium','mode':mode,'command':args,'exit_code':r.returncode,'report':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()});print('Chromium',mode,r.returncode,m['growth_bytes'],m['js_heap_growth_bytes'],flush=True)
(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')

for product in ['cli','lsp','mcp']:
 subprocess.run(['python3','/private/tmp/noyalib-100-cold-consumers.py',product],check=True)

subprocess.run(['python3','/private/tmp/noyalib-100-summarize-performance.py'],check=True)
