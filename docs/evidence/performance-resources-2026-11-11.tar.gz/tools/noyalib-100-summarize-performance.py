from pathlib import Path
import json,statistics,hashlib,tarfile,datetime
root=Path('/Users/seb/Code/Public/Rust/noyalib');out=Path('/private/tmp/noyalib-100-controlled-performance')
rows=json.loads((out/'summary.json').read_text());assert len(rows)==21 and all(row['exit_code']==0 for row in rows)
scenarios={}
for run in out.glob('*-r[123]'):
 for path in run.glob('criterion/**/new/estimates.json'):
  estimates=json.loads(path.read_text());benchmark=json.loads(path.with_name('benchmark.json').read_text());key=(run.name.rsplit('-r',1)[0],benchmark['full_id'])
  scenarios.setdefault(key,[]).append({'repetition':int(run.name[-1]),'median_ns':estimates['median']['point_estimate'],'median_confidence_interval':estimates['median']['confidence_interval'],'sampling':'Criterion batched iteration measurements; not individual request p95','observed_samples':len(json.loads(path.with_name('sample.json').read_text())['iters']),'throughput':benchmark.get('throughput')})
for run in out.glob('noyalib-wasm-r[123]'):
 data=json.loads((run/'results.json').read_text())
 for label,value in data['benchmarks'].items():
  scenarios.setdefault(('noyalib-wasm',label),[]).append({'repetition':int(run.name[-1]),'median_ns':value['median_ns'],'p95_batch_mean_ns':value['p95_batch_mean_ns'],'sampling':'JS batches of100 operations; p95 is a batch-mean quantile'})
summary=[]
for (suite,label),repetitions in sorted(scenarios.items()):
 assert len(repetitions)==3,(suite,label,len(repetitions));medians=[row['median_ns'] for row in repetitions];mean=statistics.mean(medians)
 summary.append({'suite':suite,'scenario':label,'repetitions':sorted(repetitions,key=lambda row:row['repetition']),'median_of_repetition_medians_ns':statistics.median(medians),'run_to_run_sample_cv_pct':statistics.stdev(medians)/mean*100,'run_to_run_range_pct_of_mean':(max(medians)-min(medians))/mean*100})
assert len(list((out/'cold-consumers').glob('*.json')))==3
report={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'metadata':json.loads((out/'metadata.json').read_text()),'interpretation':'Exploratory source-bound local measurements under substantial unrelated host load. During the 70 in-process scenarios the own fuzz scheduler was paused and compilers were absent. Separate cold consumer cycles ran after historical fuzz workers resumed. These results do not close dedicated-host acceptance or justify a timing threshold. In-process MCP and LSP suites measure core primitives, not their live SDK/handler dispatch.','scenario_count':len(summary),'scenarios':summary,'cold_consumers':[json.loads(path.read_text()) for path in sorted((out/'cold-consumers').glob('*.json'))]}
(out/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print('Summarized',len(summary),'three-repetition scenarios, max CV',max(row['run_to_run_sample_cv_pct'] for row in summary),flush=True)
